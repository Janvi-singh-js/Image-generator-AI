package com.example.imagismart

import  android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.squareup.picasso.Picasso
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import org.json.JSONObject
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var inputText: EditText
    private lateinit var generateBtn: MaterialButton
    private lateinit var progressBar: ProgressBar
    private lateinit var imageView: ImageView

    private val Json = "application/json; charset=utf-8".toMediaType()
    private val client: OkHttpClient = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        inputText = findViewById(R.id.textView)
        generateBtn = findViewById(R.id.generate_btn)
        progressBar = findViewById(R.id.progress_bar)
        imageView = findViewById(R.id.image_view)

        generateBtn.setOnClickListener {
            val text = inputText.text.toString().trim()
            if (text.isEmpty()) {
                inputText.error = "Text can't be empty"
                return@setOnClickListener
            }
            callAPI(text)
        }
    }

    private fun callAPI(text: String) {
        // API CALL
        setInProgress(true)
        val jsonBody = JSONObject()
        try {
            jsonBody.put("prompt", text)
            jsonBody.put("size", "1024x1024")
        } catch (e: Exception) {
            e.printStackTrace()
        }
        val requestBody = RequestBody.create(Json, jsonBody.toString())

        val request = Request.Builder()
            .url("https://api.openai.com/v1/images/generations")
            .addHeader("Authorization", "Bearer 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")
            .post(requestBody)
            .build()


        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(applicationContext, "Failed to generate image", Toast.LENGTH_LONG).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                try {
                    val jsonObject = JSONObject(response.body?.string())
                    val imageUrl = jsonObject.getJSONArray("data").getJSONObject(0).getString("url")
                    loadImage(imageUrl)
                    setInProgress(false)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        })
    }

    private fun setInProgress(inProgress: Boolean) {
        runOnUiThread {
            if (inProgress) {
                progressBar.visibility = ImageView.VISIBLE
                generateBtn.visibility = ImageView.GONE
            } else {
                progressBar.visibility = ImageView.GONE
                generateBtn.visibility = ImageView.VISIBLE
            }
        }
    }

    private fun loadImage(url: String) {
        // Load image
        runOnUiThread {
            Picasso.get().load(url).into(imageView)
        }
    }

}
